Nagisa CV 0.1.1

114 owner-approved WAVs; 119 aliases. All WAVs are unchanged from 0.1.0.
Includes the accepted trial's 23 FRQ voicing repairs and corrected oto timing for そ and ぞ.

RECOMMENDED: CLASSIC / fresamp14.exe / convergence.
Use the supplied Nagisa_CV_fresamp.ustx or Nagisa_CV_blank.ustx project.
For short そ・ぞ・く・ぐ notes, velocity 160 shortens the attacks.
WORLDLINE-R remains an alternative; the owner prefers it for ば and あ.
The song comparison favored fresamp overall. The owner noted minor remaining electrical noise.
Do not interpret the focused audition as an individual review of every pitch and note length.

The singer ID remains Nagisa_CV, so existing projects can find the updated samples.
Project renderer settings still determine which synthesis engine is used.
Preserve the supplied *_wav.frq files. Use Default phonemizer and kana lyrics.
The old installed bank and source decisions are backed up in the project archive.
Internal SoVITS labels such as Miku are model identifiers, not a voice-identity claim.
