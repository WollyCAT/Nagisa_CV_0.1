Nagisa CV 0.1.4 Short Notes

WORLDLINE-R / DEFAULT phonemizer / kana lyrics. 114 WAVs, 119 aliases.
Shortened independently unvoiced middles in 52 samples; retained releases and vowel transitions.
51 edited samples retain exact vowel/tail data; jo has uniform source headroom gain 0.60.
Positive short CV overlaps protect the previous vowel. Reviewed long voiced attacks and myo timing corrected.
VEL100 for ordinary notes; VEL150-200 helps 125ms notes, VEL200 for ~94ms notes.
These controls compress consonant duration, not note volume.
Installed alongside v0.1.3 with singer ID Nagisa_CV_ShortNotes.
New processing is authorized; owner audition approval remains pending.
